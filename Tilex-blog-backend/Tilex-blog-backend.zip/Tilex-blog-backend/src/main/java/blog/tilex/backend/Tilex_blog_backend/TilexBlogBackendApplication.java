package blog.tilex.backend.Tilex_blog_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TilexBlogBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TilexBlogBackendApplication.class, args);
	}

}
