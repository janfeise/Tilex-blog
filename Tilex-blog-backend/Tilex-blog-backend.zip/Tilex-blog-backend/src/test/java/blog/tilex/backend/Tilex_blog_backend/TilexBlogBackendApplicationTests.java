package blog.tilex.backend.Tilex_blog_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TilexBlogBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
